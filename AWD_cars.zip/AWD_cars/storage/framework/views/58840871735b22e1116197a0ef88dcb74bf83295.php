

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 col-md-offset-2">
            <div class="card">
                <div class="card-header"><br></div>

                <div class="card-body">
                        <table id="table-cars" class="table table-hover">
                        <div class="row">
                                <div class="col-md-2"></div>
                                <div class="col-md-10">
                                    <img class="w-75 justify-content-center" src="/storage/image/<?php echo e($car->image_location); ?>" alt="<?php echo e($car->make . " " . $car->model); ?>">
                                </div>
                                <div class="col-md-1"></div>
                            </div>
                            <tbody>
                                <tr>
                                    <br>
                                    <td>Make</td>
                                    <td><?php echo e($car->make); ?></td>
                                </tr>
                                <tr>
                                    <td>Model</td>
                                    <td><?php echo e($car->model); ?></td>
                                </tr>
                                <tr>
                                    <td>Price</td>
                                    <td>€<?php echo e($car->price); ?></td>
                                </tr>
                                <tr>
                                    <td>Engine size</td>
                                    <td><?php echo e($car->engine_size); ?> Litres</td>
                                </tr>
                            </tbody>
                        </table>

                        <a href="<?php echo e(route('user.cars.index')); ?>" class="btn btn-default">Back</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cc2_cars\resources\views/user/cars/show.blade.php ENDPATH**/ ?>
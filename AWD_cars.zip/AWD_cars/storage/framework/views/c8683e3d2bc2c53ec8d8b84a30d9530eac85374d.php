

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Cars</div>

                <div class="card-body">
                    <?php if(count($cars)=== 0): ?>
                        <p>There are no Cars</p>
                    <?php else: ?>
                        <table id="table-cars" class="table table-hover">
                            <thead>
                                <th>Preview</th>
                                <th>Make</th>
                                <th>Model</th>
                                <th>Price</th>
                                <th>Engine Size</th>
                                <th></th>
                            </thead>
                            <tbody>
                                <!-- for each car in the database print out the following -->
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($car->id); ?>">
                                    <td>
                                        <img src="../storage/image/<?php echo e($car->image_location); ?>" alt="<?php echo e($car->make . '' . $car->model); ?>" width="50px">
                                    </td>
                                    <td><?php echo e($car->make); ?></td>
                                    <td><?php echo e($car->model); ?></td>
                                    <td><?php echo e($car->price); ?></td>
                                    <td><?php echo e($car->engine_size); ?></td>

                                    <td>
                                        <a href="<?php echo e(route('user.cars.show', $car->id)); ?>" class="btn btn-primary">View</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cc2_cars\resources\views/user/cars/index.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header">
             <div class="row">
               <div class="col-md-11">
                 Cars 
               </div>
               <div class="col-md-1">
                 <a href="<?php echo e(route('admin.cars.create')); ?>" class="btn btn-primary justify-content-end">Add</a>
               </div>
             </div>
          </div>
          <div class="card-body">
            <?php if(count($cars)=== 0): ?>
              <p>There are no Cars!</p>
            <?php else: ?>
            <table id="table-cars" class="table table-hover">
                <thead>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Make</th>
                  <th>Model</th>
                  <th>Price</th>
                  <th>Engine Size</th>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-id="<?php echo e($car->id); ?>">
                      <td><?php echo e($car->id); ?></td>
                      <td>
                        <img src="../storage/image/<?php echo e($car->image_location); ?>" alt="test" width="50px">
                      </td>
                      <td><?php echo e($car->make); ?></td>
                      <td><?php echo e($car->model); ?></td>
                      <td><?php echo e($car->price); ?></td>
                      <td><?php echo e($car->engine_size); ?></td>
                      <td>
                        <a href="<?php echo e(route('admin.cars.show', $car->id)); ?>" class="btn btn-primary">View</a>
                        <a href="<?php echo e(route('admin.cars.edit', $car->id)); ?>" class="btn btn-warning">Edit</a>
                        <form style="display:inline-block" method="POST" action="<?php echo e(route('admin.cars.destroy', $car->id)); ?>">
                          <input type="hidden" name="_method" value="DELETE">
                          <input type="hidden" name="_token"  value="<?php echo e(csrf_token()); ?>">
                          <button type="submit" class="form-cotrol btn btn-danger">Delete</a>
                      </td>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cc2_cars\resources\views/admin/cars/index.blade.php ENDPATH**/ ?>